import pickle
import numpy as np

model = pickle.load(open("model/model.pkl", "rb"))

def predict_job(data):
    data = np.array(data).reshape(1, -1)
    return model.predict(data)[0]