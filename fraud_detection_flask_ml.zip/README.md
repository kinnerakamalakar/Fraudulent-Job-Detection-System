# Fraud Job Detection - Flask + ML

## Run Steps
1. pip install -r requirements.txt
2. python train_model.py
3. python app.py

## Project
Detects fake job postings using ML model.